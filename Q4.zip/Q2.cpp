#include<iostream>
using namespace std;
int main(){
    int n;
    cin>>n;
    int i=n;
    while(i>=1){
        int j=1;
        while(j<=i){
            cout<<"  "<<i<<"  ";
        j++;
            
        } 
        int k=1;
        while(k<=n-i){
            cout<<" ";
       
      k++;  } 
        i--;
        cout<<endl;
}
}